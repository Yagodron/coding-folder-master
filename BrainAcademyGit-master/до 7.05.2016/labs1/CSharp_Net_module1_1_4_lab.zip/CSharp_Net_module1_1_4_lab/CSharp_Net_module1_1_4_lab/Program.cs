﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_Net_module1_1_4_lab
{
    class Program
    {
        // 1) declare enum ComputerType


        // 2) declare struct Computer
 

        static void Main(string[] args)
        {
            // 3) declare jagged array of computers size 4 (4 departments)


            // 4) set the size of every array in jagged array (number of computers)


            // 5) initialize array
            // Note: use loops and if-else statements


            // 6) count total number of every type of computers
            // 7) count total number of all computers
            // Note: use loops and if-else statements
            // Note: use the same loop for 6) and 7)

 

            // 8) find computer with the largest storage (HDD) - 
            // compare HHD of every computer between each other; 
            // find position of this computer in array (indexes)
            // Note: use loops and if-else statements


            // 9) find computer with the lowest productivity (CPU and memory) - 
            // compare CPU and memory of every computer between each other; 
            // find position of this computer in array (indexes)
            // Note: use loops and if-else statements
            // Note: use logical oerators in statement conditions


                // 10) make desktop upgrade: change memory up to 8
                // change value of memory to 8 for every desktop. Don't do it for other computers
                // Note: use loops and if-else statements

        }
 
    }
}
